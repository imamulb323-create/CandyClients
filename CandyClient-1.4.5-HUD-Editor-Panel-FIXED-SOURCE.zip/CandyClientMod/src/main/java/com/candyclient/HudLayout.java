package com.candyclient;

import java.util.LinkedHashMap;
import java.util.Map;

/** Persistent layout model for the CandyClient HUD editor preview. */
public final class HudLayout {
    public static final class Element {
        public int x, y;
        public float scale;
        public boolean enabled;
        private Element(int x, int y, float scale, boolean enabled) {
            this.x = x; this.y = y; this.scale = scale; this.enabled = enabled;
        }
    }

    private static final Map<String, Element> ELEMENTS = new LinkedHashMap<>();
    static {
        reset();
    }
    private HudLayout() {}

    public static String[] names() {
        return new String[]{"Name Tag", "Status", "Effects", "Health Bar", "Held Items", "ESP Glow", "Target", "Heat Box"};
    }
    public static Element get(String name) { return ELEMENTS.get(name); }
    public static Map<String, Element> all() { return ELEMENTS; }

    public static void reset() {
        ELEMENTS.clear();
        put("Name Tag", 12, 22, true);
        put("Status", 12, 48, true);
        put("Effects", 158, 72, true);
        put("Health Bar", 12, 202, true);
        put("Held Items", 158, 202, true);
        put("ESP Glow", 158, 22, true);
        put("Target", 158, 48, true);
        put("Heat Box", 12, 176, false);
    }
    private static void put(String name, int x, int y, boolean enabled) {
        ELEMENTS.put(name, new Element(x, y, 1.0f, enabled));
    }
    public static void set(String name, int x, int y, float scale, boolean enabled) {
        if (!ELEMENTS.containsKey(name)) return;
        Element e = ELEMENTS.get(name);
        e.scale = Math.max(0.5f, Math.min(2.0f, scale));
        int estimatedWidth = (int) Math.ceil((name.length() * 6.0 + 14.0) * e.scale);
        int estimatedHeight = (int) Math.ceil(19.0 * e.scale);
        e.x = Math.max(0, Math.min(Math.max(0, 250 - estimatedWidth), x));
        e.y = Math.max(0, Math.min(Math.max(0, 274 - estimatedHeight), y));
        e.enabled = enabled;
    }
}
