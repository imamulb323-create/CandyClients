package com.candyclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.Properties;

public class CandyScreen extends Screen {
    private enum Page { COMBAT, MOVEMENT, DONUTSMP, VISUALS, MISC, NETWORK, BOTS, SETTINGS, CONFIGS, THEME, SOCIALS }
    private Page page = Page.VISUALS;
    private boolean toast = ClientConfig.getBoolean("ui.toast", true), moduleSounds = ClientConfig.getBoolean("ui.moduleSounds", true), hoverSounds = ClientConfig.getBoolean("ui.hoverSounds", true), blur = ClientConfig.getBoolean("ui.blur", true), gui3d = ClientConfig.getBoolean("ui.gui3d", false);
    private int scroll = 0;
    private String moduleSearch = "";
    private boolean searchFocused = false;
    private int selectedBot = 0;
    private boolean playstyleMenu = false;
    private boolean captureBotKey = false;
    private String selectedCombatModule = null;
    private boolean captureModuleKey = false;
    private String selectedConfig = null;
    private String configName = "My Config";
    private boolean configNameFocused = false;
    private String configMessage = "Select a profile or create a new one.";
    private String selectedHudElement = null;
    private String draggingHudElement = null;
    private int hudDragOffsetX, hudDragOffsetY;
    private final Map<String, ModuleEdit> combatEdits = new LinkedHashMap<>();
    private final Map<String, Float> hoverAnimations = new HashMap<>();
    private final Map<String, Float> toggleAnimations = new HashMap<>();
    private static final class ModuleEdit {
        String keybind = "-";
        String mode = "Normal";
        int range = 4;
        int delay = 100;
        boolean advanced = false;
    }
    private ModuleEdit editFor(String name) { return combatEdits.computeIfAbsent(name, k -> new ModuleEdit()); }
    private static final int PANEL_W = 620, PANEL_H = 390, SIDEBAR = 142;

    public CandyScreen() { super(Text.literal("CandyClient")); }
    private void saveUiSettings() {
        ClientConfig.setBoolean("ui.toast", toast);
        ClientConfig.setBoolean("ui.moduleSounds", moduleSounds);
        ClientConfig.setBoolean("ui.hoverSounds", hoverSounds);
        ClientConfig.setBoolean("ui.blur", blur);
        ClientConfig.setBoolean("ui.gui3d", gui3d);
        ClientConfig.save();
    }
    public static void openPage(String pageName) {
        CandyScreen screen = new CandyScreen();
        try { screen.page = Page.valueOf(pageName.toUpperCase(java.util.Locale.ROOT)); }
        catch (IllegalArgumentException ignored) { screen.page = Page.VISUALS; }
        MinecraftClient.getInstance().setScreen(screen);
    }
    private int x() { return (width - PANEL_W) / 2; }
    private int y() { return (height - PANEL_H) / 2; }
    private void sound() { if (moduleSounds) MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 0.8f)); }
    private int accent() { return Modules.accent(); }
    private void box(DrawContext g, int x1, int y1, int x2, int y2, int color) { g.fill(x1,y1,x2,y2,color); }
    private void label(DrawContext g, String s, int px, int py, int color) { g.drawText(textRenderer, s, px, py, color, false); }
    private float animate(Map<String, Float> values, String key, float target, float delta) {
        float current = values.getOrDefault(key, target);
        float speed = Math.min(1.0f, Math.max(0.08f, delta * 0.45f + 0.16f));
        float next = current + (target - current) * speed;
        if (Math.abs(next - target) < 0.005f) next = target;
        values.put(key, next);
        return next;
    }
    private int mix(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = (int)(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = (int)(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int gr = (int)(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = (int)((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (gr << 8) | b;
    }
    private void animatedSwitch(DrawContext g, String id, int x, int y, boolean enabled, float delta) {
        float position = animate(toggleAnimations, id, enabled ? 1f : 0f, delta);
        box(g, x, y, x + 30, y + 15, mix(0xFF303640, accent(), position));
        int knobX = x + 2 + Math.round(position * 13f);
        box(g, knobX, y + 2, knobX + 11, y + 13, 0xFFF0F2F6);
    }
    // Tiny hand-drawn 5x5 pixel icons: crisp at every GUI scale and no external assets/fonts required.
    private void drawIcon(DrawContext g, String name, int px, int py, int color, int cell) {
        String[] rows = switch (name.toLowerCase(java.util.Locale.ROOT)) {
            case "combat", "sword", "axe", "crystal" -> new String[]{"....#", "...#.", "..#..", ".#...", "#..##"};
            case "movement", "move", "zoom" -> new String[]{"..#..", ".##..", "#####", "..##.", "..#.."};
            case "donutsmp", "donut", "server" -> new String[]{".###.", "#...#", "#.#.#", "#...#", ".###."};
            case "visuals", "eye", "hud" -> new String[]{".....", ".###.", "#...#", ".###.", "..#.."};
            case "misc", "wrench" -> new String[]{"##...", ".##..", "..##.", "...##", "....#"};
            case "network", "ping" -> new String[]{"....#", "...##", "..###", ".####", "#####"};
            case "bots", "bot" -> new String[]{".###.", "#.#.#", "#####", "##.##", "#...#"};
            case "settings", "gear" -> new String[]{"..#..", ".###.", "##.##", ".###.", "..#.."};
            case "configs", "file" -> new String[]{".###.", "#...#", "#..##", "#....", "#####"};
            case "theme", "palette" -> new String[]{".###.", "#.#.#", "#...#", ".#.#.", "..#.."};
            case "socials", "users" -> new String[]{".#.#.", "#####", ".#.#.", "##.##", "#...#"};
            case "fps", "clock" -> new String[]{".###.", "#...#", "#.#.#", "#...#", ".###."};
            case "coordinates", "region coordinates" -> new String[]{"#...#", ".#.#.", "..#..", ".#.#.", "#...#"};
            case "keystrokes", "toggle sprint" -> new String[]{"..#..", ".###.", "#.#.#", "..#..", "..#.."};
            case "armor status", "health bar" -> new String[]{"#####", "#...#", "#####", ".#.#.", ".#.#."};
            case "crosshair", "target" -> new String[]{"..#..", "..#..", "#####", "..#..", "..#.."};
            case "ping monitor", "connection status", "latency graph", "packet rate display" -> new String[]{"#...#", "##.##", "#.#.#", "#...#", "#...#"};
            default -> new String[]{"#####", "#...#", "..#..", "#...#", "#####"};
        };
        for (int row = 0; row < rows.length; row++)
            for (int col = 0; col < rows[row].length(); col++)
                if (rows[row].charAt(col) == '#') box(g, px + col * cell, py + row * cell, px + (col + 1) * cell, py + (row + 1) * cell, color);
    }

    @Override public void render(DrawContext g, int mx, int my, float delta) {
        renderBackground(g, mx, my, delta);
        int x=x(), y=y();
        box(g,x-2,y-2,x+PANEL_W+2,y+PANEL_H+2,accent());
        box(g,x,y,x+PANEL_W,y+PANEL_H,0xFF010913);
        box(g,x,y,x+SIDEBAR,y+PANEL_H,0xFF101A28);
        // Soft pulse on the CandyClient brand mark; the animation is cosmetic only.
        float pulse = (float)(0.5 + 0.5 * Math.sin(System.nanoTime() / 420_000_000.0));
        int logoColor = mix(accent(), 0xFFFFD0A3, pulse * 0.32f);
        box(g, x+12, y+10, x+34, y+34, mix(0x00101010, accent(), 0.10f + pulse * 0.13f));
        label(g,"C",x+16,y+15,logoColor); label(g,"CANDY",x+38,y+14,0xFFFFFFFF);
        label(g,"CLIENT  •  1.21.11",x+17,y+31,0xFF9AA7B8);
        String[] groups={"MODULES","Combat","Movement","DonutSMP","Visuals","Misc","Network","Bots","GENERAL","Settings","Configs","Theme","Socials"};
        Page[] pages={null,Page.COMBAT,Page.MOVEMENT,Page.DONUTSMP,Page.VISUALS,Page.MISC,Page.NETWORK,Page.BOTS,null,Page.SETTINGS,Page.CONFIGS,Page.THEME,Page.SOCIALS};
        int yy=y+58;
        for(int i=0;i<groups.length;i++) {
            if(pages[i]==null) { label(g,groups[i],x+16,yy,0xFF77869A); yy+=19; continue; }
            boolean active=page==pages[i];
            float hover=animate(hoverAnimations,"nav:"+groups[i],active?1f:(mx>=x+8&&mx<=x+SIDEBAR-8&&my>=yy-4&&my<=yy+17?0.55f:0f),delta);
            if(hover>0.01f) box(g,x+8,yy-4,x+SIDEBAR-8,yy+17,mix(0x001E160F,0xFF382719,hover));
            float iconPulse = active ? (float)(0.5 + 0.5 * Math.sin(System.nanoTime() / 300_000_000.0)) : hover;
            if (active) box(g, x+12, yy, x+29, yy+17, mix(0x00101010, accent(), 0.10f + iconPulse * 0.18f));
            int iconCell = 2 + (hover > 0.35f ? 1 : 0);
            drawIcon(g, groups[i], x+15, yy+2, active?mix(accent(),0xFFFFD0A3,iconPulse*0.25f):mix(0xFF8794A6,0xFFFFB36A,hover), iconCell);
            label(g,groups[i],x+34,yy,active?accent():mix(0xFFD0D7E2,0xFFFFB36A,hover)); yy+=25;
        }
        box(g,x+10,y+PANEL_H-52,x+SIDEBAR-10,y+PANEL_H-10,0xFF172333);
        label(g,"ITZ_IMAMUL99Z",x+20,y+PANEL_H-37,0xFFFFFFFF);
        label(g,"CandyClient account",x+20,y+PANEL_H-23,0xFF8D9AAD);
        label(g,title(),x+SIDEBAR+18,y+17,0xFFFFFFFF);
        label(g,"CandyClient  /  "+title(),x+SIDEBAR+18,y+34,0xFF8997A9);
        String clock=java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
        label(g,clock,x+PANEL_W-52,y+19,accent());
        if (page == Page.VISUALS) {
            int bx = x + PANEL_W - 151;
            box(g, bx, y+9, bx+91, y+34, gui3d ? 0xFF70401F : 0xFF202D3D);
            box(g, bx, y+9, bx+2, y+34, accent());
            label(g, gui3d ? "MODULES" : "HUD EDITOR", bx+10, y+18, 0xFFFFFFFF);
        }
        box(g,x+SIDEBAR+14,y+48,x+PANEL_W-14,y+49,0xFF283444);
        switch(page) {
            case SETTINGS -> renderSettings(g,x,y,mx,my);
            case THEME -> renderThemes(g,x,y,mx,my);
            case CONFIGS -> renderConfigs(g,x,y);
            case SOCIALS -> renderSocials(g,x,y);
            case BOTS -> renderBots(g,x,y);
            case COMBAT -> renderCombat(g,x,y);
            default -> { if (page == Page.VISUALS && gui3d) render3DHudEditor(g,x,y,mx,my); else renderModules(g,x,y,mx,my); }
        }
        super.render(g,mx,my,delta);
    }
    private String title() { return switch(page) { case DONUTSMP -> "DonutSMP"; default -> page.name().charAt(0)+page.name().substring(1).toLowerCase(); }; }
    private List<String> modules() {
        return switch(page) {
            case VISUALS -> List.of("FPS","CPS","Keystrokes","Coordinates","Armor Status","Clock","Ping","Crosshair","Hit Color","Item Counter","Potion Effects");
            case MOVEMENT -> List.of("Toggle Sprint","Zoom");
            case MISC -> List.of("Candy HUD", "Fullbright");
            case DONUTSMP -> List.of(Modules.DONUTSMP_MODULES);
            case NETWORK -> List.of(Modules.NETWORK_MODULES);
            default -> List.of("No built-in modules in this category yet");
        };
    }
    private List<String> filteredModules() {
        String q = moduleSearch.trim().toLowerCase(java.util.Locale.ROOT);
        if (q.isEmpty()) return modules();
        return modules().stream().filter(n -> n.toLowerCase(java.util.Locale.ROOT).contains(q)
                || description(n).toLowerCase(java.util.Locale.ROOT).contains(q)).toList();
    }
    private void renderModules(DrawContext g,int x,int y,int mx,int my) {
        if (selectedCombatModule != null) { renderCombatEditor(g, x, y); return; }
        label(g,"Toggle client-side tools • Right-click a card for its own settings",x+SIDEBAR+18,y+32,0xFF9AA7B8);
        int sx=x+SIDEBAR+18, sy=y+49;
        box(g,sx,sy,sx+446,sy+27,searchFocused?0xFF332319:0xFF17191D);
        box(g,sx,sy,sx+2,sy+27,searchFocused?accent():0xFF65402B);
        label(g,"⌕",sx+9,sy+7,0xFFFFA45B);
        label(g,moduleSearch.isEmpty()?"Search modules...":moduleSearch,sx+27,sy+7,moduleSearch.isEmpty()?0xFF77818F:0xFFF4F4F4);
        if (!moduleSearch.isEmpty()) label(g,"×",sx+427,sy+7,0xFFFFA45B);
        box(g,x+SIDEBAR+14,y+82,x+PANEL_W-14,y+83,0xFF713B20);
        int ox=x+SIDEBAR+18, oy=y+91, cardW=218, cardH=54, gap=10, idx=0;
        List<String> visibleModules = filteredModules();
        if (visibleModules.isEmpty()) label(g,"No modules match your search.",ox+8,oy+12,0xFF9AA7B8);
        for(String n:visibleModules) {
            int col=idx%2,row=idx/2-scroll;
            int cx=ox+col*(cardW+10), cy=oy+row*(cardH+9);
            if(cy<oy || cy+cardH>y+PANEL_H-12) { idx++; continue; }
            boolean hovered=mx>=cx&&mx<=cx+cardW&&my>=cy&&my<=cy+cardH;
            float hover=animate(hoverAnimations,"module:"+page+":"+n,hovered?1f:0f,delta);
            box(g,cx,cy,cx+cardW,cy+cardH,mix(0xFF171719,0xFF24201D,hover));
            box(g,cx,cy,cx+cardW,cy+2,mix(0xFF4A2B1C,accent(),hover));
            drawIcon(g,n,cx+9,cy+11,mix(0xFF8794A6,0xFFFFA45B,hover),2);
            label(g,n,cx+25,cy+10,mix(0xFFF2F3F6,0xFFFFC18B,hover));
            label(g,description(n),cx+25,cy+29,0xFF9299A5);
            label(g,"KeyBind:  "+editFor(n).keybind,cx+25,cy+42,0xFF727C8A);
            boolean on=Modules.on(n);
            animatedSwitch(g,"module:"+n,cx+cardW-45,cy+19,on,delta);
            idx++;
        }
    }
    private String description(String n) { return switch(n) {
        case "FPS"->"Display frames per second"; case "CPS"->"Clicks per second counter";
        case "Keystrokes"->"Show movement keys"; case "Coordinates"->"Display world position";
        case "Armor Status"->"Show equipped armor"; case "Server Info"->"Show current server details";
        case "Region Coordinates"->"Display your current coordinates"; case "Item Price Notes"->"Personal item-price reference";
        case "Trade Checklist"->"Personal trading checklist"; case "Chunk Borders"->"Show local chunk boundaries";
        case "Netherite Notes"->"Personal mining notes"; case "Trader Notes"->"Save trader location notes";
        case "DonutSMP Status"->"Display connection and session status";
        case "Ping Monitor"->"Display current server latency"; case "Connection Status"->"Show connection state";
        case "Latency Graph"->"Visualize recent ping samples"; case "Packet Rate Display"->"Display network traffic counters";
        default->"Client-side display option"; }; }


    // CandyClient's floating HUD editor: a perspective-styled preview with per-element controls.
    private List<String> hudElementNames() { return List.of(HudLayout.names()); }
    private boolean hudElementOn(String name) { return HudLayout.get(name).enabled; }
    private void render3DHudEditor(DrawContext g, int x, int y, int mx, int my) {
        int left=x+SIDEBAR+14, top=y+58;
        label(g,"HUD EDITOR PANEL",left,top,accent());
        label(g,"Drag elements, toggle visibility and adjust their scale",left,top+15,0xFF8997A9);
        int sx=left, sy=top+39, sw=250, sh=274;
        box(g,sx,sy,sx+sw,sy+sh,0xFF101A27);
        box(g,sx+8,sy+8,sx+sw-8,sy+sh-8,0xFF172638);
        for(int i=0;i<5;i++) box(g,sx+16+i*7,sy+sh-34+i*3,sx+sw-16-i*7,sy+sh-32+i*3,0xFF26394A);
        box(g,sx+94,sy+220,sx+166,sy+230,0x66000000);
        // Stylized player mannequin remains a preview aid; HUD chips are independently draggable.
        box(g,sx+111,sy+69,sx+149,sy+111,0xFFB98B62);
        box(g,sx+111,sy+69,sx+149,sy+80,0xFF9A633D);
        box(g,sx+117,sy+85,sx+123,sy+91,0xFF26384A); box(g,sx+137,sy+85,sx+143,sy+91,0xFF26384A);
        box(g,sx+106,sy+112,sx+154,sy+178,0xFF477B69);
        box(g,sx+91,sy+116,sx+106,sy+171,0xFFB98B62); box(g,sx+154,sy+116,sx+169,sy+171,0xFFB98B62);
        box(g,sx+109,sy+178,sx+130,sy+218,0xFF60452F); box(g,sx+130,sy+178,sx+151,sy+218,0xFF60452F);
        box(g,sx+107,sy+214,sx+130,sy+222,0xFF303C4C); box(g,sx+130,sy+214,sx+153,sy+222,0xFF303C4C);
        for (String name : hudElementNames()) {
            HudLayout.Element e=HudLayout.get(name);
            if(e.enabled) hudChip(g,sx+e.x,sy+e.y,name,true,e.scale,selectedHudElement!=null&&selectedHudElement.equals(name));
        }
        int px=sx+258, pw=188;
        box(g,px,sy,px+pw,sy+sh,0xFF111B29);
        label(g,"HUD ELEMENTS",px+9,sy+10,0xFFFFFFFF);
        String[] names=HudLayout.names();
        for(int i=0;i<names.length;i++) {
            int cy=sy+27+i*22;
            boolean selected=names[i].equals(selectedHudElement);
            box(g,px+7,cy,px+pw-7,cy+21,selected?0xFF49301F:0xFF202D3D);
            label(g,names[i],px+13,cy+7,hudElementOn(names[i])?accent():0xFF8997A9);
            label(g,hudElementOn(names[i])?"ON":"OFF",px+pw-34,cy+7,0xFFD5DCE6);
        }
        int cy=sy+207;
        if(selectedHudElement!=null) {
            HudLayout.Element e=HudLayout.get(selectedHudElement);
            label(g,"EDIT  "+selectedHudElement,px+9,cy,accent());
            box(g,px+8,cy+17,px+62,cy+39,e.enabled?accent():0xFF455164); label(g,e.enabled?"VISIBLE":"HIDDEN",px+13,cy+24,0xFFFFFFFF);
            box(g,px+70,cy+17,px+104,cy+39,0xFF303D4E); label(g,"-",px+83,cy+24,0xFFFFFFFF);
            label(g,String.format(java.util.Locale.ROOT,"%.1fx",e.scale),px+111,cy+24,0xFFFFFFFF);
            box(g,px+145,cy+17,px+179,cy+39,0xFF303D4E); label(g,"+",px+158,cy+24,0xFFFFFFFF);
            label(g,"X "+e.x+"  Y "+e.y,px+9,cy+46,0xFF8997A9);
            box(g,px+137,cy+43,px+179,cy+64,0xFF303D4E); label(g,"RESET",px+142,cy+50,0xFFFFFFFF);
        } else label(g,"Choose an element",px+9,cy+12,0xFF8997A9);
        label(g,"Drag chips • Right-click to select",left,sy+sh+8,0xFF8997A9);
    }
    private void hudChip(DrawContext g,int x,int y,String name,boolean on,float scale,boolean selected){
        int w=Math.max(48,Math.round((textRenderer.getWidth(name)+14)*scale)), h=Math.max(14,Math.round(19*scale));
        box(g,x,y,x+w,y+h,selected?0xFF68401F:(on?0xCC173B35:0xCC293341));
        box(g,x,y,x+Math.max(2,Math.round(3*scale)),y+h,on?0xFFFF963D:0xFF63758B);
        g.drawText(textRenderer,name,x+Math.max(5,Math.round(7*scale)),y+Math.max(3,Math.round(5*scale)),on?0xFFFFFFFF:0xFF9AA7B8,false);
    }

    private void renderCombat(DrawContext g, int x, int y) {
        if (selectedCombatModule != null) {
            renderCombatEditor(g, x, y);
            return;
        }
        label(g, "COMBAT MODULES  •  INDIVIDUAL CONFIGURATION", x+SIDEBAR+18, y+61, accent());
        label(g, "Toggle cards to store your preferred practice settings.", x+SIDEBAR+18, y+75, 0xFF8997A9);
        int ox=x+SIDEBAR+10, oy=y+96, cardW=218, cardH=34, gapX=8, gapY=6;
        for (int i=0;i<Modules.COMBAT_MODULES.length;i++) {
            int col=i%2, row=i/2-scroll;
            int cx=ox+col*(cardW+gapX), cy=oy+row*(cardH+gapY);
            if (cy<oy || cy+cardH>y+PANEL_H-10) continue;
            String name=Modules.COMBAT_MODULES[i];
            boolean on=Modules.on(name);
            box(g,cx,cy,cx+cardW,cy+cardH,0xFF1B1A1D);
            box(g,cx,cy,cx+3,cy+cardH,on?accent():0xFF343943);
            label(g,name,cx+10,cy+5,0xFFF0F2F6);
            label(g,"KeyBind:  "+editFor(name).keybind,cx+10,cy+19,0xFF8993A1);
            box(g,cx+cardW-36,cy+10,cx+cardW-10,cy+24,on?accent():0xFF46505F);
            box(g,on?cx+cardW-22:cx+cardW-34,cy+12,on?cx+cardW-12:cx+cardW-24,cy+22,0xFFFFFFFF);
        }
        int totalRows=(Modules.COMBAT_MODULES.length+1)/2;
        label(g,"SCROLL  •  "+Math.min(scroll+6,totalRows)+" / "+totalRows,x+PANEL_W-105,y+PANEL_H-18,0xFF77869A);
    }


    private void renderCombatEditor(DrawContext g, int x, int y) {
        ModuleEdit e = editFor(selectedCombatModule);
        int left = x + SIDEBAR + 18, top = y + 62, right = x + PANEL_W - 18;
        label(g, "MODULE  /  INDIVIDUAL SETTINGS", left, top, accent());
        box(g, left, top + 24, right, y + PANEL_H - 18, 0xFF171D27);
        label(g, selectedCombatModule, left + 16, top + 40, 0xFFFFFFFF);
        label(g, "Settings are stored independently for this module.", left + 16, top + 58, 0xFF9AA7B8);
        box(g, left + 16, top + 82, right - 16, top + 83, 0xFF303B49);
        label(g, "Keybind", left + 16, top + 98, 0xFFD5DCE6);
        box(g, right - 142, top + 91, right - 16, top + 115, captureModuleKey ? 0xFF573018 : 0xFF263241);
        label(g, captureModuleKey ? "PRESS A KEY..." : e.keybind, right - 128, top + 99, 0xFFFFFFFF);
        label(g, "Mode", left + 16, top + 139, 0xFFD5DCE6);
        box(g, right - 142, top + 132, right - 16, top + 156, 0xFF263241);
        label(g, e.mode + "  <", right - 126, top + 140, accent());
        label(g, "Range: " + e.range, left + 16, top + 180, 0xFFD5DCE6);
        box(g, left + 16, top + 202, right - 16, top + 208, 0xFF3B4655);
        box(g, left + 16, top + 202, left + 16 + (right - left - 32) * e.range / 32, top + 208, accent());
        label(g, "Delay: " + e.delay + " ms", left + 16, top + 228, 0xFFD5DCE6);
        box(g, right - 142, top + 220, right - 16, top + 245, 0xFF263241);
        label(g, "CHANGE", right - 126, top + 228, 0xFFFFFFFF);
        toggleRow(g, left + 16, top + 263, "Advanced options", e.advanced, "Show additional module-specific options");
        if (e.advanced) label(g, "Advanced settings are stored per module.", left + 16, top + 318, 0xFF9AA7B8);
        button(g, left + 16, y + PANEL_H - 48, left + 112, y + PANEL_H - 22, "BACK", 0xFF63758B);
        button(g, right - 112, y + PANEL_H - 48, right - 16, y + PANEL_H - 22, "SAVE", accent());
    }

    private Path combatEditPath(String name) {
        String safe = name.toLowerCase().replaceAll("[^a-z0-9]+", "-").replaceAll("^-|-$", "");
        return MinecraftClient.getInstance().runDirectory.toPath().resolve("config/candyclient/combat/" + safe + ".properties");
    }
    private void saveCombatEdit(String name) {
        try {
            ModuleEdit e = editFor(name); Properties p = new Properties();
            p.setProperty("keybind", e.keybind); p.setProperty("mode", e.mode);
            p.setProperty("range", String.valueOf(e.range)); p.setProperty("delay", String.valueOf(e.delay));
            p.setProperty("advanced", String.valueOf(e.advanced));
            Files.createDirectories(combatEditPath(name).getParent());
            try (OutputStream out = Files.newOutputStream(combatEditPath(name))) { p.store(out, "CandyClient combat module settings"); }
        } catch (IOException ignored) { }
    }
    private void loadCombatEdit(String name) {
        try {
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(combatEditPath(name))) { p.load(in); }
            ModuleEdit e = editFor(name); e.keybind = p.getProperty("keybind", "-");
            e.mode = p.getProperty("mode", "Normal"); e.range = Math.max(1, Math.min(32, Integer.parseInt(p.getProperty("range", "4"))));
            e.delay = Math.max(0, Math.min(1000, Integer.parseInt(p.getProperty("delay", "100"))));
            e.advanced = Boolean.parseBoolean(p.getProperty("advanced", "false"));
        } catch (IOException | NumberFormatException ignored) { }
    }

    private void renderSettings(DrawContext g,int x,int y,int mx,int my) {
        label(g,"INTERFACE",x+SIDEBAR+18,y+62,accent());
        setting(g,x+SIDEBAR+18,y+84,"Menu Bind","RIGHT SHIFT","Key that opens this menu");
        toggleRow(g,x+SIDEBAR+18,y+137,"3D GUI",gui3d,"Floating menu mode");
        toggleRow(g,x+SIDEBAR+18,y+190,"Toast Notifications",toast,"Show module notifications");
        toggleRow(g,x+SIDEBAR+18,y+243,"Module Toggle Sounds",moduleSounds,"Play a sound on module toggle");
        toggleRow(g,x+SIDEBAR+18,y+296,"Hover Sound",hoverSounds,"Soft sound when hovering");
        toggleRow(g,x+SIDEBAR+322,y+137,"Frosted Blur",blur,"Blur the game behind the menu");
        setting(g,x+SIDEBAR+322,y+190,"Version","1.21.11","Fabric client build");
    }
    private void setting(DrawContext g,int x,int y,String a,String b,String c) { box(g,x,y,x+280,y+44,0xFF172333); label(g,a,x+11,y+8,0xFFFFFFFF); label(g,c,x+11,y+24,0xFF8997A9); label(g,b,x+205,y+16,accent()); }
    private void toggleRow(DrawContext g,int x,int y,String name,boolean on,String sub) { box(g,x,y,x+280,y+44,0xFF172333); label(g,name,x+11,y+8,0xFFFFFFFF); label(g,sub,x+11,y+24,0xFF8997A9); animatedSwitch(g,"setting:"+name,x+241,y+15,on,0.5f); }
    private void renderThemes(DrawContext g,int x,int y,int mx,int my) {
        label(g,"PRESETS",x+SIDEBAR+18,y+62,accent());
        for(int i=0;i<Modules.THEMES.length;i++) { int cx=x+SIDEBAR+18+(i%3)*145, cy=y+88+(i/3)*65; box(g,cx,cy,cx+133,cy+51,Modules.theme==i?0xFF3A2A20:0xFF172333); label(g,Modules.THEME_NAMES[i],cx+10,cy+10,0xFFFFFFFF); box(g,cx+10,cy+30,cx+122,cy+39,Modules.THEMES[i]); }
        label(g,"APPEARANCE",x+SIDEBAR+18,y+280,accent());
        int rowX=x+SIDEBAR+18, rowY=y+300;
        box(g,rowX,rowY,x+PANEL_W-18,rowY+40,0xFF172333);
        int favorite=ClientConfig.getInt("ui.favoriteTheme",-1);
        box(g,rowX+8,rowY+7,rowX+126,rowY+33,favorite==Modules.theme?0xFF49301F:0xFF263344);
        label(g,favorite==Modules.theme?"★ FAVORITE":"☆ SET FAVORITE",rowX+15,rowY+16,favorite==Modules.theme?accent():0xFFD5DCE6);
        box(g,rowX+134,rowY+7,rowX+230,rowY+33,0xFF263344);
        label(g,"SHUFFLE",rowX+157,rowY+16,0xFFD5DCE6);
        label(g,Modules.THEME_NAMES[Math.floorMod(Modules.theme,Modules.THEME_NAMES.length)],rowX+244,rowY+16,accent());
        toggleRow(g,x+SIDEBAR+18,y+346,"Frosted Blur",blur,"Blur the world behind the menu");
    }
    private void renderConfigs(DrawContext g,int x,int y) {
        int left=x+SIDEBAR+18, top=y+58;
        label(g,"CONFIG PROFILES",left,top,accent());
        label(g,"Save, load, rename, delete and export your local settings",left,top+16,0xFF8997A9);
        box(g,left,top+39,left+190,top+269,0xFF111923);
        label(g,"SAVED PROFILES",left+10,top+49,0xFFD5DCE6);
        List<String> profiles=ConfigProfiles.list();
        if(profiles.isEmpty()) label(g,"No saved profiles yet.",left+12,top+77,0xFF8997A9);
        for(int i=0;i<Math.min(7,profiles.size());i++) {
            String name=profiles.get(i); int rowY=top+72+i*25;
            boolean selected=name.equals(selectedConfig);
            box(g,left+7,rowY,left+183,rowY+22,selected?0xFF49301F:0xFF202B39);
            label(g,name,left+15,rowY+7,selected?accent():0xFFE3E8EF);
        }
        int rx=left+202;
        label(g,"PROFILE NAME",rx,top+44,0xFFD5DCE6);
        box(g,rx,top+64,rx+119,top+91,configNameFocused?0xFF38271D:0xFF202B39);
        label(g,configName.isEmpty()?"Type a name...":configName,rx+8,top+73,0xFFFFFFFF);
        button(g,rx+125,top+64,rx+236,top+91,"SAVE NEW",accent());
        button(g,rx,top+104,rx+112,top+132,"LOAD",0xFF63758B);
        button(g,rx+120,top+104,rx+236,top+132,"OVERWRITE",accent());
        button(g,rx,top+143,rx+112,top+171,"RENAME",0xFF63758B);
        button(g,rx+120,top+143,rx+236,top+171,"DELETE",0xFF9B4141);
        button(g,rx,top+182,rx+236,top+210,"EXPORT COPY",0xFF455C72);
        label(g,configMessage,left,top+282,0xFFB8C2D0);
        label(g,"Profiles are stored locally in config/candyclient/profiles",left,top+301,0xFF77879A);
    }
    private void renderBots(DrawContext g,int x,int y) {
        BotProfiles.Profile p = BotProfiles.ALL.get(selectedBot);
        int left=x+SIDEBAR+8, top=y+57;
        // Compact three-column layout inspired by the supplied CORZ reference.
        box(g,left,top,left+36,y+PANEL_H-12,0xFF111923);
        for(int i=0;i<BotProfiles.ALL.size();i++) {
            int by=top+8+i*37;
            boolean active=i==selectedBot;
            box(g,left+4,by,left+32,by+29,active?0xFF4A2B16:0xFF202B39);
            label(g,botGlyph(i),left+11,by+8,active?accent():0xFFD1D9E5);
            if(active) box(g,left+2,by+3,left+4,by+26,accent());
        }
        int previewX=left+42, previewW=139;
        box(g,previewX,top,previewX+previewW,y+PANEL_H-12,0xFF111923);
        label(g,"CP "+String.format("%02d",selectedBot+1),previewX+10,top+10,0xFF8997A9);
        label(g,p.enabled?"ENABLED":"OFFLINE",previewX+74,top+10,p.enabled?0xFF45D483:0xFF8997A9);
        // Stylized preview emblem; this panel intentionally avoids pretending to render a live player model.
        box(g,previewX+31,top+82,previewX+108,top+159,0xFF1A2635);
        label(g,botGlyph(selectedBot),previewX+56,top+99,accent());
        label(g,p.name.toUpperCase()+" BOT",previewX+13,top+178,0xFFD5DCE6);
        label(g,"PRACTICE PROFILE",previewX+13,top+195,0xFF8997A9);

        int rx=previewX+previewW+7, rw=x+PANEL_W-12-rx;
        box(g,rx,top,x+PANEL_W-12,y+PANEL_H-12,0xFF111923);
        label(g,"PVP BOT",rx+10,top+9,0xFF8997A9);
        label(g,p.name+" PvP Bot",rx+10,top+24,0xFFFFFFFF);
        label(g,p.enabled?"ON":"OFF",rx+rw-38,top+25,p.enabled?accent():0xFF8997A9);
        label(g,"Toggle profile settings (practice config only)",rx+10,top+42,0xFF8997A9);
        box(g,rx+8,top+59,rx+rw-8,top+60,0xFF2B3543);

        label(g,"Keybind",rx+10,top+70,0xFFD5DCE6);
        box(g,rx+rw-76,top+65,rx+rw-12,top+86,captureBotKey?0xFF503018:0xFF202B39);
        label(g,captureBotKey?"PRESS KEY":p.keybind,rx+rw-58,top+72,0xFFFFFFFF);
        label(g,"Playstyle",rx+10,top+98,0xFFD5DCE6);
        box(g,rx+rw-105,top+92,rx+rw-12,top+114,playstyleMenu?0xFF503018:0xFF202B39);
        label(g,"LT"+p.styleTier+"  v",rx+rw-82,top+99,accent());
        label(g,"Fight Range: "+p.range,rx+10,top+127,0xFFD5DCE6);
        box(g,rx+10,top+145,rx+rw-12,top+150,0xFF394454);
        box(g,rx+10,top+145,rx+10+(rw-22)*Math.min(1f,p.range/32f),top+150,accent());
        label(g,"Turn Speed",rx+10,top+161,0xFFD5DCE6);
        box(g,rx+rw-105,top+157,rx+rw-12,top+179,0xFF202B39);
        label(g,p.turnSpeed+"%",rx+rw-73,top+164,0xFFFFFFFF);
        toggleCompact(g,rx+10,top+190,"Strafe",p.strafe,rw);
        toggleCompact(g,rx+10,top+212,"Defensive",p.defensive,rw);
        toggleCompact(g,rx+10,top+234,"Combos",p.combo,rw);
        int by=y+PANEL_H-38;
        button(g,rx+8,by,rx+rw/3-3,by+25,"SAVE",accent());
        button(g,rx+rw/3+1,by,rx+(rw*2)/3-3,by+25,"LOAD",0xFF63758B);
        button(g,rx+(rw*2)/3+1,by,rx+rw-8,by+25,"RESET",0xFFE34B4B);
        if(playstyleMenu) {
            int dx=rx+rw-105, dy=top+115;
            box(g,dx,dy,rx+rw-12,dy+91,0xFF080D14);
            for(int tier=5;tier>=1;tier--) {
                int oy=dy+(5-tier)*18;
                if(p.styleTier==tier) box(g,dx+2,oy,rx+rw-14,oy+17,0xFF63330F);
                label(g,"LT"+tier,dx+12,oy+4,p.styleTier==tier?accent():0xFFFFFFFF);
            }
        }
    }
    private String botGlyph(int i) { return switch(i) { case 0->"◇"; case 1->"⚔"; case 2->"✚"; case 3->"⚒"; case 4->"✦"; case 5->"◆"; case 6->"➶"; default->"▣"; }; }
    private void toggleCompact(DrawContext g,int x,int y,String name,boolean on,int width) {
        label(g,name,x,y+4,0xFFD5DCE6);
        box(g,x+width-42,y+1,x+width-12,y+16,on?accent():0xFF455164);
        box(g,on?x+width-26:x+width-40,y+3,on?x+width-14:x+width-28,y+14,0xFFFFFFFF);
    }
    private void button(DrawContext g,int x1,int y1,int x2,int y2,String text,int color) {
        box(g,x1,y1,x2,y2,0xFF202B39); box(g,x1,y1,x2,y1+2,color);
        label(g,text,x1+7,y1+9,0xFFFFFFFF);
    }
    private Path botProfilePath(int index){return MinecraftClient.getInstance().runDirectory.toPath().resolve("config/candyclient/bots/"+BotProfiles.id(index)+".properties");}
    private void saveBot(int index){try{BotProfiles.Profile b=BotProfiles.ALL.get(index);Properties p=new Properties();p.setProperty("enabled",String.valueOf(b.enabled));p.setProperty("range",String.valueOf(b.range));p.setProperty("turn",String.valueOf(b.turnSpeed));p.setProperty("styleTier",String.valueOf(b.styleTier));p.setProperty("keybind",b.keybind);p.setProperty("strafe",String.valueOf(b.strafe));p.setProperty("defensive",String.valueOf(b.defensive));p.setProperty("combo",String.valueOf(b.combo));Files.createDirectories(botProfilePath(index).getParent());try(OutputStream o=Files.newOutputStream(botProfilePath(index))){p.store(o,"CandyClient bot profile");}}catch(Exception ignored){}}
    private void loadBot(int index){try{BotProfiles.Profile b=BotProfiles.ALL.get(index);Properties p=new Properties();Path current=botProfilePath(index);if(!Files.exists(current)){String[] legacyNames={"crystal","sword","pot","axe-shield","mace","uhc","bow","cart"};Path legacy=MinecraftClient.getInstance().runDirectory.toPath().resolve("config/candyclient/bots/"+legacyNames[index]+".properties");if(Files.exists(legacy))current=legacy;}try(InputStream in=Files.newInputStream(current)){p.load(in);}b.enabled=Boolean.parseBoolean(p.getProperty("enabled","false"));b.range=Math.max(1,Math.min(32,Integer.parseInt(p.getProperty("range",String.valueOf(b.range)))));b.turnSpeed=Math.max(1,Math.min(100,Integer.parseInt(p.getProperty("turn",String.valueOf(b.turnSpeed)))));b.styleTier=Math.max(1,Math.min(5,Integer.parseInt(p.getProperty("styleTier",String.valueOf(b.styleTier)))));b.keybind=p.getProperty("keybind",b.keybind);b.strafe=Boolean.parseBoolean(p.getProperty("strafe",String.valueOf(b.strafe)));b.defensive=Boolean.parseBoolean(p.getProperty("defensive",String.valueOf(b.defensive)));b.combo=Boolean.parseBoolean(p.getProperty("combo",String.valueOf(b.combo)));}catch(Exception ignored){}}
    private void resetBot(int index){BotProfiles.Profile b=BotProfiles.ALL.get(index);BotProfiles.Profile d=defaultBot(index);b.enabled=false;b.range=d.range;b.turnSpeed=d.turnSpeed;b.styleTier=5;b.keybind="R";b.strafe=true;b.defensive=true;b.combo=true;}
    private BotProfiles.Profile defaultBot(int i){return switch(i){case 0->new BotProfiles.Profile("Crystal PvP","Crystal placement / pop timing",4,75);case 1->new BotProfiles.Profile("Sword PvP","Spacing / hit trading",3,65);case 2->new BotProfiles.Profile("Pot PvP","Healing / splash timing",4,55);case 3->new BotProfiles.Profile("Axe & Shield PvP","Shield pressure / disable",3,60);case 4->new BotProfiles.Profile("Mace PvP","Vertical engage / smash timing",5,80);case 5->new BotProfiles.Profile("UHC PvP","Rod / bow / melee switching",4,50);case 6->new BotProfiles.Profile("Bow PvP","Projectile spacing / leading",18,45);default->new BotProfiles.Profile("Cart PvP","Minecart practice / timing",6,60);};}
    @Override public boolean charTyped(char chr,int modifiers) {
        if (searchFocused && !Character.isISOControl(chr) && moduleSearch.length()<40) { moduleSearch += chr; scroll=0; return true; }
        if (configNameFocused && !Character.isISOControl(chr) && configName.length()<24 && (Character.isLetterOrDigit(chr)||chr==' '||chr=='_'||chr=='-')) { configName += chr; return true; }
        return super.charTyped(chr,modifiers);
    }
    @Override public boolean keyPressed(int keyCode,int scanCode,int modifiers){
        if (searchFocused && keyCode==256) { searchFocused=false; return true; }
        if (searchFocused && keyCode==259) { if(!moduleSearch.isEmpty()) moduleSearch=moduleSearch.substring(0,moduleSearch.length()-1); scroll=0; return true; }
        if (configNameFocused && keyCode==256) { configNameFocused=false; return true; }
        if (configNameFocused && keyCode==259) { if(!configName.isEmpty()) configName=configName.substring(0,configName.length()-1); return true; }
        if(captureModuleKey && selectedCombatModule != null){editFor(selectedCombatModule).keybind=net.minecraft.client.util.InputUtil.fromKeyCode(keyCode,scanCode).getTranslationKey();captureModuleKey=false;saveCombatEdit(selectedCombatModule);return true;}if(captureBotKey){BotProfiles.ALL.get(selectedBot).keybind=net.minecraft.client.util.InputUtil.fromKeyCode(keyCode,scanCode).getTranslationKey();captureBotKey=false;ClientConfig.save();return true;}return super.keyPressed(keyCode,scanCode,modifiers);}
    private void chip(DrawContext g,int x,int y,String text,boolean on) {
        box(g,x,y,x+32,y+18,on?accent():0xFF455164);
        label(g,text,x+5,y+5,0xFFFFFFFF);
    }
    private void renderSocials(DrawContext g,int x,int y) { label(g,"CANDYCLIENT COMMUNITY",x+SIDEBAR+18,y+68,accent()); label(g,"Community links can be added when official URLs are provided.",x+SIDEBAR+18,y+100,0xFFD0D7E2); label(g,"No external links are configured in this build.",x+SIDEBAR+18,y+121,0xFF8997A9); }
    @Override public boolean mouseClicked(Click click,boolean doubled) {
        double mx=click.x(),my=click.y(); int x=x(),y=y();
        if (page == Page.VISUALS && mx >= x+PANEL_W-151 && mx <= x+PANEL_W-60 && my >= y+9 && my <= y+34) {
            gui3d = !gui3d;
            ClientConfig.setBoolean("ui.gui3d", gui3d);
            ClientConfig.save();
            sound();
            return true;
        }
        if(mx>=x+8&&mx<=x+SIDEBAR-8) {
            int yy=y+58; Page[] p={null,Page.COMBAT,Page.MOVEMENT,Page.DONUTSMP,Page.VISUALS,Page.MISC,Page.NETWORK,Page.BOTS,null,Page.SETTINGS,Page.CONFIGS,Page.THEME,Page.SOCIALS};
            for(Page q:p) { if(q==null){yy+=19;continue;} if(my>=yy-4&&my<=yy+17){page=q;scroll=0;selectedCombatModule=null;captureModuleKey=false;sound();return true;} yy+=25; }
        }
        if (page==Page.VISUALS||page==Page.MOVEMENT||page==Page.MISC||page==Page.DONUTSMP||page==Page.NETWORK) {
            int sx=x+SIDEBAR+18, sy=y+49;
            if (my>=sy && my<=sy+27 && mx>=sx && mx<=sx+446) {
                searchFocused=true;
                if (mx>=sx+414 && !moduleSearch.isEmpty()) moduleSearch="";
                return true;
            }
            searchFocused=false;
        }
        if(page==Page.THEME) {
            for(int i=0;i<Modules.THEMES.length;i++) { int cx=x+SIDEBAR+18+(i%3)*145, cy=y+88+(i/3)*65; if(mx>=cx&&mx<=cx+133&&my>=cy&&my<=cy+51) { Modules.theme=i; ClientConfig.save(); sound(); return true; } }
            int rowX=x+SIDEBAR+18, rowY=y+300;
            if(my>=rowY+7&&my<=rowY+33&&mx>=rowX+8&&mx<=rowX+126) { int favorite=ClientConfig.getInt("ui.favoriteTheme",-1); ClientConfig.setInt("ui.favoriteTheme",favorite==Modules.theme?-1:Modules.theme); ClientConfig.save(); sound(); return true; }
            if(my>=rowY+7&&my<=rowY+33&&mx>=rowX+134&&mx<=rowX+230) { int next=Modules.theme; if(Modules.THEMES.length>1) { do { next=java.util.concurrent.ThreadLocalRandom.current().nextInt(Modules.THEMES.length); } while(next==Modules.theme); } Modules.theme=next; ClientConfig.save(); sound(); return true; }
            if(my>=y+346&&my<=y+390) { blur=!blur; ClientConfig.setBoolean("ui.blur",blur); ClientConfig.save(); sound(); return true; }
        }
        if(page==Page.SETTINGS) { if(my>=y+137&&my<=y+181&&mx>x+SIDEBAR+18&&mx<x+SIDEBAR+302)gui3d=!gui3d; else if(my>=y+190&&my<=y+234&&mx>x+SIDEBAR+18&&mx<x+SIDEBAR+302)toast=!toast; else if(my>=y+243&&my<=y+287&&mx>x+SIDEBAR+18&&mx<x+SIDEBAR+302)moduleSounds=!moduleSounds; else if(my>=y+296&&my<=y+340&&mx>x+SIDEBAR+18&&mx<x+SIDEBAR+302)hoverSounds=!hoverSounds; else if(my>=y+137&&my<=y+181&&mx>x+SIDEBAR+322)blur=!blur; else return super.mouseClicked(click,doubled); saveUiSettings(); sound(); return true; }
        if(page==Page.COMBAT || selectedCombatModule != null) {
            if (selectedCombatModule != null) {
                ModuleEdit e = editFor(selectedCombatModule);
                int left=x+SIDEBAR+18, top=y+62, right=x+PANEL_W-18;
                if (my >= y+PANEL_H-48 && my <= y+PANEL_H-22 && mx >= left+16 && mx <= left+112) { selectedCombatModule=null; captureModuleKey=false; sound(); return true; }
                if (my >= y+PANEL_H-48 && my <= y+PANEL_H-22 && mx >= right-112 && mx <= right-16) { saveCombatEdit(selectedCombatModule); sound(); return true; }
                if (my >= top+91 && my <= top+115 && mx >= right-142) { captureModuleKey=true; sound(); return true; }
                if (my >= top+132 && my <= top+156 && mx >= right-142) { e.mode = switch(e.mode) { case "Normal" -> "Fast"; case "Fast" -> "Precise"; default -> "Normal"; }; sound(); return true; }
                if (my >= top+195 && my <= top+216 && mx >= left+16 && mx <= right-16) { e.range=Math.max(1,Math.min(32,(int)((mx-(left+16))*32.0/(right-left-32))+1)); sound(); return true; }
                if (my >= top+220 && my <= top+245 && mx >= right-142) { e.delay=e.delay>=1000?0:e.delay+50; sound(); return true; }
                if (my >= top+263 && my <= top+307 && mx >= left+16 && mx <= left+296) { e.advanced=!e.advanced; sound(); return true; }
                return true;
            }
            if (page == Page.COMBAT) {
            int ox=x+SIDEBAR+10, oy=y+96, cardW=218, cardH=34, gapX=8, gapY=6;
            for(int i=0;i<Modules.COMBAT_MODULES.length;i++) {
                int col=i%2, row=i/2-scroll, cx=ox+col*(cardW+gapX), cy=oy+row*(cardH+gapY);
                if(mx>=cx&&mx<=cx+cardW&&my>=cy&&my<=cy+cardH) {
                    String module = Modules.COMBAT_MODULES[i];
                    if (click.button() == 1) { selectedCombatModule=module; loadCombatEdit(module); captureModuleKey=false; sound(); return true; }
                    if (mx >= cx+cardW-42) { Modules.toggle(module); ClientConfig.save(); sound(); return true; }
                    return true;
                }
            }
            }
        }
        if(page==Page.VISUALS && gui3d) {
            int left=x+SIDEBAR+14, top=y+58, sx=left, sy=top+39, px=sx+258, pw=188;
            // Palette selection and right-click settings selection.
            for(int i=0;i<HudLayout.names().length;i++) {
                String name=HudLayout.names()[i]; int cy=sy+27+i*22;
                if(mx>=px+7&&mx<=px+pw-7&&my>=cy&&my<=cy+21) { selectedHudElement=name; draggingHudElement=null; sound(); return true; }
            }
            if(selectedHudElement!=null) {
                HudLayout.Element e=HudLayout.get(selectedHudElement); int cy=sy+207;
                if(mx>=px+8&&mx<=px+62&&my>=cy+17&&my<=cy+39){e.enabled=!e.enabled;ClientConfig.save();sound();return true;}
                if(mx>=px+70&&mx<=px+104&&my>=cy+17&&my<=cy+39){HudLayout.set(selectedHudElement,e.x,e.y,e.scale-0.1f,e.enabled);ClientConfig.save();sound();return true;}
                if(mx>=px+145&&mx<=px+179&&my>=cy+17&&my<=cy+39){HudLayout.set(selectedHudElement,e.x,e.y,e.scale+0.1f,e.enabled);ClientConfig.save();sound();return true;}
                if(mx>=px+137&&mx<=px+179&&my>=cy+43&&my<=cy+64){HudLayout.reset();selectedHudElement=null;ClientConfig.save();sound();return true;}
            }
            // Clicking a preview chip selects it; left-click starts dragging, right-click opens its edit controls.
            for(String name:HudLayout.names()) {
                HudLayout.Element e=HudLayout.get(name); if(!e.enabled) continue;
                int cx=sx+e.x, cy=sy+e.y;
                int cw=Math.max(48,Math.round((textRenderer.getWidth(name)+14)*e.scale)), ch=Math.max(14,Math.round(19*e.scale));
                if(mx>=cx&&mx<=cx+cw&&my>=cy&&my<=cy+ch) {
                    selectedHudElement=name;
                    if(click.button()==0){draggingHudElement=name;hudDragOffsetX=(int)mx-cx;hudDragOffsetY=(int)my-cy;}
                    sound();return true;
                }
            }
            return true;
        }
        if(page==Page.VISUALS||page==Page.MOVEMENT||page==Page.MISC||page==Page.DONUTSMP||page==Page.NETWORK) {
            int ox=x+SIDEBAR+18,oy=y+91,idx=0;
            for(String n:filteredModules()) { int col=idx%2,row=idx/2-scroll,cx=ox+col*228,cy=oy+row*63;
                if(mx>=cx&&mx<=cx+218&&my>=cy&&my<=cy+54&&!n.startsWith("No built")) {
                    if (click.button() == 1) { selectedCombatModule=n; loadCombatEdit(n); captureModuleKey=false; sound(); return true; }
                    if (mx >= cx+218-48) { Modules.toggle(n); ClientConfig.save(); sound(); return true; }
                    return true;
                } idx++;
            }
        }
        if(page==Page.BOTS) {
            int left=x+SIDEBAR+8, top=y+57;
            int previewX=left+42, previewW=139, rx=previewX+previewW+7, rw=x+PANEL_W-12-rx;
            if(mx>=left+4&&mx<=left+32&&my>=top+8&&my<top+8+BotProfiles.ALL.size()*37){selectedBot=Math.max(0,Math.min(BotProfiles.ALL.size()-1,(int)((my-(top+8))/37)));playstyleMenu=false;captureBotKey=false;sound();return true;}
            BotProfiles.Profile b=BotProfiles.ALL.get(selectedBot);
            if(playstyleMenu){int dy=top+115,dx=rx+rw-105;if(mx>=dx&&mx<=rx+rw-12&&my>=dy&&my<=dy+91){int tier=5-(int)((my-dy)/18);b.styleTier=Math.max(1,Math.min(5,tier));playstyleMenu=false;ClientConfig.save();sound();return true;}playstyleMenu=false;}
            if(mx>=rx+rw-48&&my>=top+18&&my<=top+43){b.enabled=!b.enabled;ClientConfig.save();sound();return true;}
            if(mx>=rx+rw-76&&my>=top+65&&my<=top+86){captureBotKey=true;sound();return true;}
            if(mx>=rx+rw-105&&my>=top+92&&my<=top+114){playstyleMenu=true;sound();return true;}
            if(my>=top+140&&my<=top+156){b.range=Math.min(32,b.range+1);ClientConfig.save();sound();return true;}
            if(my>=top+157&&my<=top+181){b.turnSpeed=b.turnSpeed>=100?10:b.turnSpeed+5;ClientConfig.save();sound();return true;}
            if(my>=top+190&&my<=top+208){b.strafe=!b.strafe;ClientConfig.save();sound();return true;}
            if(my>=top+212&&my<=top+230){b.defensive=!b.defensive;ClientConfig.save();sound();return true;}
            if(my>=top+234&&my<=top+252){b.combo=!b.combo;ClientConfig.save();sound();return true;}
            int by=y+PANEL_H-38;
            if(my>=by&&my<=by+25){if(mx>=rx+8&&mx<rx+rw/3-3)saveBot(selectedBot);else if(mx>=rx+rw/3+1&&mx<rx+(rw*2)/3-3)loadBot(selectedBot);else if(mx>=rx+(rw*2)/3+1&&mx<=rx+rw-8)resetBot(selectedBot);ClientConfig.save();sound();return true;}
        }
        if(page==Page.CONFIGS) {
            int left=x+SIDEBAR+18, top=y+58, rx=left+202;
            if(mx>=rx&&mx<=rx+119&&my>=top+64&&my<=top+91){configNameFocused=true;searchFocused=false;return true;}
            if(mx>=rx+125&&mx<=rx+236&&my>=top+64&&my<=top+91){boolean ok=ConfigProfiles.save(configName);configMessage=ok?"Saved profile: "+configName:"Could not save. Check the profile name.";if(ok)selectedConfig=configName;configNameFocused=false;sound();return true;}
            if(mx>=left+7&&mx<=left+183&&my>=top+72&&my<=top+72+7*25){int i=(int)((my-(top+72))/25);List<String> list=ConfigProfiles.list();if(i>=0&&i<Math.min(7,list.size())){selectedConfig=list.get(i);configName=selectedConfig;configMessage="Selected: "+selectedConfig;}return true;}
            if(selectedConfig!=null&&mx>=rx&&mx<=rx+112&&my>=top+104&&my<=top+132){boolean ok=ConfigProfiles.load(selectedConfig);configMessage=ok?"Loaded profile: "+selectedConfig:"Could not load selected profile.";sound();return true;}
            if(selectedConfig!=null&&mx>=rx+120&&mx<=rx+236&&my>=top+104&&my<=top+132){boolean ok=ConfigProfiles.save(selectedConfig);configMessage=ok?"Overwrote profile: "+selectedConfig:"Could not overwrite profile.";sound();return true;}
            if(selectedConfig!=null&&mx>=rx&&mx<=rx+112&&my>=top+143&&my<=top+171){String old=selectedConfig;boolean ok=ConfigProfiles.rename(old,configName);configMessage=ok?"Renamed "+old+" to "+configName:"Rename failed (new name may already exist).";if(ok)selectedConfig=configName; sound();return true;}
            if(selectedConfig!=null&&mx>=rx+120&&mx<=rx+236&&my>=top+143&&my<=top+171){boolean ok=ConfigProfiles.delete(selectedConfig);configMessage=ok?"Deleted profile: "+selectedConfig:"Could not delete selected profile.";if(ok)selectedConfig=null;sound();return true;}
            if(selectedConfig!=null&&mx>=rx&&mx<=rx+236&&my>=top+182&&my<=top+210){boolean ok=ConfigProfiles.exportToGameConfig(selectedConfig);configMessage=ok?"Exported a copy to config/candyclient/exports":"Export failed.";sound();return true;}
            configNameFocused=false;
        }
        return super.mouseClicked(click,doubled);
    }
    @Override public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if(page==Page.VISUALS && gui3d && draggingHudElement!=null) {
            int sx=x()+SIDEBAR+14, sy=y()+58+39;
            HudLayout.Element e=HudLayout.get(draggingHudElement);
            HudLayout.set(draggingHudElement,(int)click.x()-sx-hudDragOffsetX,(int)click.y()-sy-hudDragOffsetY,e.scale,e.enabled);
            return true;
        }
        return super.mouseDragged(click,offsetX,offsetY);
    }
    @Override public boolean mouseReleased(Click click) {
        if(draggingHudElement!=null){draggingHudElement=null;ClientConfig.save();return true;}
        return super.mouseReleased(click);
    }
    @Override public boolean mouseScrolled(double mx,double my,double horizontal,double vertical){
        int count=page==Page.COMBAT?Modules.COMBAT_MODULES.length:modules().size();
        int max=Math.max(0,(count+1)/2-4);
        scroll=Math.max(0,Math.min(max,scroll-(int)Math.signum(vertical)));return true;
    }
    @Override public boolean shouldPause(){return false;}
}
