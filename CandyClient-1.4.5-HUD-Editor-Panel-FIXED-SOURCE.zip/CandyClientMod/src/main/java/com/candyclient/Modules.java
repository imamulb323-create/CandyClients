package com.candyclient;

import java.util.LinkedHashMap;
import java.util.Map;

public final class Modules {
    private Modules() {}
    public static final int[] THEMES = {
        0xFFFF7A18, // Inferno
        0xFFFF4FA3, // Bubblegum
        0xFF2EE6A6, // Mint
        0xFF6EE7FF, // Glacier
        0xFF9B6BFF, // Ultraviolet
        0xFFFFD93B, // Lemon
        0xFFFFB21C, // Goku - Super Saiyan
        0xFF9BCBFF, // Goku - Ultra Instinct
        0xFFFF8A24  // Naruto - Sage Mode
    };
    public static final String[] THEME_NAMES = {
        "Inferno", "Bubblegum", "Mint", "Glacier", "Ultraviolet", "Lemon",
        "Goku - Super Saiyan", "Goku - Ultra Instinct", "Naruto - Sage Mode"
    };
    public static int theme = 0;
    // DonutSMP and Network pages intentionally contain passive, client-side utilities only.
    // No packet manipulation, stealth, automation, or server-exploitation features are included.
    public static final String[] DONUTSMP_MODULES = {
        "Server Info", "Region Coordinates", "Item Price Notes", "Trade Checklist",
        "Chunk Borders", "Netherite Notes", "Trader Notes", "DonutSMP Status"
    };
    public static final String[] NETWORK_MODULES = {
        "Ping Monitor", "Connection Status", "Latency Graph", "Packet Rate Display"
    };
    public static final String[] COMBAT_MODULES = {
        "Aim Assist", "Auto Aggro Pearl", "AutoClicker", "Auto Hotbar", "Auto Jump Reset",
        "Auto Totem", "Auto XP", "Auto Crystal", "Hit Boxes", "Hit Swap", "Auto Mace",
        "Perfect Wind Charge", "Safe Anchor", "Trident Assist", "W Tap", "Anchor Macro",
        "AutoCart", "Auto Hit Crystal", "Auto Inventory Totem", "Auto Shield Disabler",
        "AutoTrap", "Criticals", "Crystal Optimizer", "Hit Select", "Key Pearl",
        "Obsidian Optimizer", "Reach", "Silent Aim", "Trigger Bot"
    };
    public static final Map<String, Boolean> MAP = new LinkedHashMap<>();
    static {
        MAP.put("FPS", true); MAP.put("CPS", true); MAP.put("Keystrokes", true);
        MAP.put("Coordinates", true); MAP.put("Armor Status", true);
        MAP.put("Candy HUD", false);
        MAP.put("Clock", false); MAP.put("Ping", false); MAP.put("Crosshair", false);
        MAP.put("Fullbright", false); MAP.put("Zoom", false); MAP.put("Hit Color", false);
        MAP.put("Toggle Sprint", false); MAP.put("Item Counter", false); MAP.put("Potion Effects", false);
        for (String module : COMBAT_MODULES) MAP.put(module, false);
        for (String module : DONUTSMP_MODULES) MAP.put(module, false);
        for (String module : NETWORK_MODULES) MAP.put(module, false);
    }
    public static boolean on(String n) { return MAP.getOrDefault(n, false); }
    public static void toggle(String n) { MAP.put(n, !on(n)); }
    public static int accent() { return THEMES[Math.floorMod(theme, THEMES.length)]; }
}
