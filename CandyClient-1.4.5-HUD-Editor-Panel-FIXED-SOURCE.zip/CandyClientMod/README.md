# CandyClient 1.3.3 — Build & Compatibility Preparation

Target: Minecraft 1.21.11 / Fabric / Java 21.

## Changes in this update
- Kept the existing CandyClient 1.3.2 source and feature set; no project rewrite.
- Updated the Fabric Loader dependency to 0.18.1 and Fabric API to 0.141.1+1.21.11, matching the current Fabric 1.21.11 guidance checked for this update.
- Switched to Fabric's documented remapping Loom plugin ID for Minecraft 1.21.11 and retained Loom 1.14.
- Added Gradle 8.14.3 distribution settings and lightweight `gradlew` / `gradlew.bat` bootstrap scripts. The scripts download Gradle on first run; they do not require a separately installed Gradle executable.
- Added Gradle caching and conservative configuration-cache settings.

## Build
Requires JDK 21 and internet access for the first build. From this folder run:

- Linux/macOS/Termux: `./gradlew build`
- Windows: `gradlew.bat build`

The first build downloads Gradle, Minecraft, mappings, Fabric Loader, Fabric API and Loom. A successful source ZIP or static check is not the same as a successful mod build.

## Current verification
- ZIP structure and JSON resources: checked during packaging.
- Shell bootstrap syntax: checked with `sh -n`.
- Gradle compilation: **not run in this environment** because Gradle is not installed and network access for downloading the full build toolchain is unavailable here.
- Minecraft launch in MJ Launcher: **not run**; this environment cannot operate the user's Android launcher.

## Existing functional limitations
- HUD editor has persisted layout/preview controls, but not every preview widget is wired to a live in-world renderer.
- DonutSMP and Network tools remain passive/client-side UI utilities where indicated in the code; no packet manipulation or evasion features are added.
- Cosmetics are local preference controls, not a server-backed cosmetics economy.
- The eight bot entries are saved profile presets, not autonomous bots or combat automation.


## Theme presets (1.3.4)
The Theme page includes three new anime-inspired accent presets:
- Goku - Super Saiyan (gold)
- Goku - Ultra Instinct (silver-blue)
- Naruto - Sage Mode (orange)

These are original color treatments and text labels, not copyrighted character artwork. Existing dark surfaces are retained for readability. Theme selection is saved in the normal CandyClient config.

## CandyClient 1.3.5 — Anime Aura UI
- Added theme-aware animated hub aura labels for Goku Super Saiyan, Goku Ultra Instinct, and Naruto Sage Mode.
- Added lightweight animated accent rails and sparkle pixels to the hub header.
- Updated displayed/project version to 1.3.5.
- Effects are UI-only and use the selected theme accent; no external textures or gameplay automation are added.

Build verification: not performed in this environment. Run `./gradlew build` with Java 21 and network access to resolve Fabric/Gradle dependencies.


## Version 1.4.0 — Animated Theme Backdrops
- Added lightweight procedural energy particles and edge glow to the CandyClient Hub.
- Backdrop palette adapts to Super Saiyan, Ultra Instinct, Sage Mode, and the standard color themes.
- No copyrighted character artwork or external textures are bundled; the effects are abstract theme-inspired visuals.
- Animation is UI-only and does not change gameplay or network behavior.

Build with Java 21 using `./gradlew build` (or `gradlew.bat build` on Windows). A successful build and in-game launch still need to be verified in an environment with the Gradle distribution and Minecraft/Fabric dependencies available.


## 1.4.1 Cosmetics / Backdrop update
- Added four Hub backdrop styles: Aura, Particles, Energy Grid, and Minimal.
- Added an Animated Backdrop toggle.
- Backdrop style and animation preference persist in `config/candyclient.properties`.
- Backdrop remains procedural and lightweight; no external anime artwork is bundled.


## 1.4.2 Theme Favorites & Shuffle
- Added a one-click favorite marker for the currently selected theme.
- Added a Shuffle control that selects a different built-in theme at random.
- Favorite selection is stored locally in `config/candyclient.properties` and survives restarts.
- Existing theme presets, backdrop controls, and blur setting are preserved.
- UI-only change; no gameplay or network behavior is added.

Build verification: not performed in this environment. Use Java 21 and a working Gradle installation to run `gradle build`; test the resulting mod in the target Minecraft/Fabric instance.


## Version 1.4.3 Screenshot-inspired Candy HUD
- Added an optional compact black/orange dashboard HUD, enabled from Misc → Candy HUD.
- Includes player/world header and clock, FPS and coordinates, totem/golden-apple/crystal/XP-bottle counters, hotbar preview, WASD and mouse input display, and a lightweight FPS history graph.
- Existing individual HUD elements remain available when Candy HUD is disabled.
- All counters are local inventory/UI information; no gameplay automation or packet manipulation is added.

Build verification: not performed in this environment.


## Version 1.4.4 Full Inventory HUD
- Added a three-row, nine-column inventory preview showing all 27 main storage slots.
- Inventory item icons and stack counts update from the live player inventory.
- Kept the separate hotbar preview, resource counters, keystrokes, mouse panel, performance graph, and existing HUD.


## 1.4.5 — HUD Editor Panel
- Added a dedicated HUD EDITOR / MODULES switch in the Visuals page header for quick access.
- HUD editor panel is now directly accessible without visiting Settings.
- Renamed the editor heading and refreshed its helper text.
- Editor mode preference is saved immediately and persists across restarts.


## 1.4.5 build-failure hotfix (source review)
- Removed the optional screen mixins and their Mixin annotation-processor setup. The supplied GitHub Actions log reports missing obfuscation mappings for `TitleScreen.init` and `SplashOverlay.render`; these mixins triggered the reported annotation-processor errors.
- The custom title-screen replacement and custom resource-reload overlay are disabled in this hotfix. The CandyClient screen remains available from its Right Shift keybind.
- HUD Editor panel code (preview selection, drag positioning, enable/disable, scale controls, reset, and persisted layout) is retained.
- This source change has **not yet been compiled** here: Gradle distribution download was blocked by unavailable DNS/network access. Do not treat it as a verified JAR until GitHub Actions completes successfully.
