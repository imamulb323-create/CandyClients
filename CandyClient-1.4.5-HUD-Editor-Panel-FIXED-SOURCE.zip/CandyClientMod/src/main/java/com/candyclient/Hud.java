package com.candyclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import java.util.ArrayDeque;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Hud {
    private static final ArrayDeque<Long> clicks = new ArrayDeque<>();
    private static boolean lastAttack;
    private static final ArrayDeque<Integer> fpsHistory = new ArrayDeque<>();

    public static void tick(MinecraftClient c) {
        boolean a = c.options.attackKey.isPressed();
        long now = System.currentTimeMillis();
        if (a && !lastAttack) clicks.addLast(now);
        lastAttack = a;
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
        if (fpsHistory.isEmpty() || now % 250 < 50) {
            fpsHistory.addLast(c.getCurrentFps());
            while (fpsHistory.size() > 24) fpsHistory.pollFirst();
        }
    }

    private static int pill(DrawContext g, TextRenderer tr, int x, int y, String text) {
        int w = tr.getWidth(text) + 10;
        g.fill(x, y, x + w, y + 14, 0xB01F1030);
        g.fill(x, y, x + 2, y + 14, Modules.accent());
        g.drawText(tr, text, x + 6, y + 3, 0xFFFFFFFF, true);
        return y + 17;
    }

    private static void key(DrawContext g, TextRenderer tr, int x, int y, String label, KeyBinding k) {
        g.fill(x, y, x + 18, y + 18, k.isPressed() ? Modules.accent() : 0xB01F1030);
        g.drawText(tr, label, x + 6, y + 5, 0xFFFFFFFF, true);
    }

    /** Screenshot-inspired compact black/orange dashboard HUD. */
    private static void renderCandyHud(DrawContext g, MinecraftClient c, TextRenderer tr) {
        int accent = Modules.accent();
        int panel = 0xC914151B;
        int edge = 0xFF38251F;
        int x = 8, y = 7;
        String player = c.player.getName().getString();
        String world = c.getCurrentServerEntry() == null ? "Singleplayer" : c.getCurrentServerEntry().name;
        String clock = LocalTime.now().format(DateTimeFormatter.ofPattern("h:mm:ss a"));
        g.fill(x, y, x + 330, y + 22, panel);
        g.fill(x, y, x + 3, y + 22, accent);
        g.drawText(tr, "CANDY CLIENT", x + 9, y + 7, 0xFFFFD5B0, true);
        g.drawText(tr, player, x + 103, y + 7, 0xFFFFFFFF, true);
        g.drawText(tr, world.length() > 14 ? world.substring(0, 14) : world, x + 181, y + 7, 0xFFD5D5D5, true);
        g.drawText(tr, clock, x + 270, y + 7, 0xFFFFC08A, true);

        y += 27;
        g.fill(x, y, x + 150, y + 17, panel);
        g.drawText(tr, c.getCurrentFps() + " FPS", x + 7, y + 5, accent, true);
        g.drawText(tr, "XYZ " + c.player.getBlockX() + " " + c.player.getBlockY() + " " + c.player.getBlockZ(), x + 61, y + 5, 0xFFE4E4E4, true);

        // Resource counters: totems, golden apples, end crystals and experience bottles.
        int[] counts = new int[4];
        for (int i = 0; i < c.player.getInventory().size(); i++) {
            ItemStack stack = c.player.getInventory().getStack(i);
            String id = net.minecraft.registry.Registries.ITEM.getId(stack.getItem()).toString();
            if (id.endsWith(":totem_of_undying")) counts[0] += stack.getCount();
            else if (id.endsWith(":golden_apple") || id.endsWith(":enchanted_golden_apple")) counts[1] += stack.getCount();
            else if (id.endsWith(":end_crystal")) counts[2] += stack.getCount();
            else if (id.endsWith(":experience_bottle")) counts[3] += stack.getCount();
        }
        panel(g, tr, x, y + 22, 150, 42, "RESOURCES", accent);
        String[] icons = {"Tot ", "Gap ", "Cry ", "XP "};
        for (int i = 0; i < 4; i++) g.drawText(tr, icons[i] + counts[i], x + 7 + i * 36, y + 48, 0xFFFFD8B5, true);

        // Main inventory preview: all 27 slots in the familiar three-row layout.
        // Slots 9..35 are the storage inventory; the hotbar remains separate below.
        int inventoryY = y + 69;
        panel(g, tr, x, inventoryY, 222, 77, "INVENTORY", accent);
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                int slot = 9 + row * 9 + col;
                int sx = x + 7 + col * 23, sy = inventoryY + 20 + row * 18;
                g.fill(sx, sy, sx + 20, sy + 17, 0xA52B2A2C);
                ItemStack stack = c.player.getInventory().getStack(slot);
                if (!stack.isEmpty()) {
                    g.drawItem(stack, sx + 2, sy);
                    g.drawStackOverlay(tr, stack, sx + 2, sy);
                }
            }
        }

        // Hotbar preview panel.
        int hotbarY = inventoryY + 83;
        panel(g, tr, x, hotbarY, 222, 52, "HOTBAR", accent);
        for (int i = 0; i < 9; i++) {
            int sx = x + 7 + i * 23, sy = hotbarY + 20;
            g.fill(sx, sy, sx + 20, sy + 20, 0xA52B2A2C);
            if (i == c.player.getInventory().getSelectedSlot()) g.fill(sx, sy, sx + 20, sy + 2, accent);
            ItemStack stack = c.player.getInventory().getStack(i);
            if (!stack.isEmpty()) { g.drawItem(stack, sx + 2, sy + 2); g.drawStackOverlay(tr, stack, sx + 2, sy + 2); }
        }

        // WASD + mouse input cards.
        int ky = hotbarY + 57;
        panel(g, tr, x, ky, 91, 91, "KEYS", accent);
        key(g, tr, x + 36, ky + 22, "W", c.options.forwardKey);
        key(g, tr, x + 14, ky + 43, "A", c.options.leftKey);
        key(g, tr, x + 36, ky + 43, "S", c.options.backKey);
        key(g, tr, x + 58, ky + 43, "D", c.options.rightKey);
        g.fill(x + 10, ky + 67, x + 43, ky + 83, c.options.attackKey.isPressed() ? accent : 0xB01F1030);
        g.fill(x + 47, ky + 67, x + 80, ky + 83, c.options.useKey.isPressed() ? accent : 0xB01F1030);
        g.drawText(tr, "LMB", x + 17, ky + 72, 0xFFFFFFFF, true);
        g.drawText(tr, "RMB", x + 54, ky + 72, 0xFFFFFFFF, true);
        g.fill(x + 99, ky, x + 190, ky + 91, panel);
        g.drawText(tr, "MOUSE", x + 107, ky + 7, 0xFFFFD5B0, true);
        g.fill(x + 122, ky + 27, x + 166, ky + 72, 0xB01F1030);
        g.fill(x + 143, ky + 27, x + 145, ky + 72, 0xFF4C4140);
        g.fill(x + 122, ky + 48, x + 166, ky + 50, 0xFF4C4140);
        g.fill(x + 143, ky + 47, x + 145, ky + 49, accent);

        // Small FPS history graph.
        int gy = ky + 98;
        panel(g, tr, x, gy, 190, 55, "PERFORMANCE  " + c.getCurrentFps() + " FPS", accent);
        int index = 0;
        for (int fps : fpsHistory) {
            int bar = Math.max(2, Math.min(22, fps / 5));
            int bx = x + 8 + index * 7;
            g.fill(bx, gy + 47 - bar, bx + 4, gy + 47, accent);
            index++;
        }

        int bottom = c.getWindow().getScaledHeight() - 18;
        g.fill(8, bottom, 156, bottom + 15, panel);
        g.drawText(tr, "XYZ " + c.player.getBlockX() + "  " + c.player.getBlockY() + "  " + c.player.getBlockZ(), 14, bottom + 4, 0xFFEDEDED, true);
        int right = c.getWindow().getScaledWidth();
        g.fill(right - 112, c.getWindow().getScaledHeight() - 19, right - 7, c.getWindow().getScaledHeight() - 4, panel);
        g.drawText(tr, "CANDY CLIENT", right - 105, c.getWindow().getScaledHeight() - 15, 0xFFFFC08A, true);
    }

    private static void panel(DrawContext g, TextRenderer tr, int x, int y, int w, int h, String title, int accent) {
        g.fill(x, y, x + w, y + h, 0xC914151B);
        g.fill(x, y, x + w, y + 1, 0xFF38251F);
        g.fill(x, y, x + 2, y + h, accent);
        g.drawText(tr, title, x + 7, y + 6, 0xFFFFD5B0, true);
    }

    public static void render(DrawContext g, RenderTickCounter tick) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        TextRenderer tr = c.textRenderer;
        if (Modules.on("Candy HUD")) { renderCandyHud(g, c, tr); return; }
        int y = 6;
        if (Modules.on("FPS")) y = pill(g, tr, 6, y, c.getCurrentFps() + " FPS");
        if (Modules.on("CPS")) y = pill(g, tr, 6, y, clicks.size() + " CPS");
        if (Modules.on("Coordinates"))
            y = pill(g, tr, 6, y, "XYZ " + c.player.getBlockX() + " " + c.player.getBlockY() + " " + c.player.getBlockZ());
        if (Modules.on("Keystrokes")) {
            y += 2;
            key(g, tr, 26, y, "W", c.options.forwardKey);
            key(g, tr, 6, y + 20, "A", c.options.leftKey);
            key(g, tr, 26, y + 20, "S", c.options.backKey);
            key(g, tr, 46, y + 20, "D", c.options.rightKey);
            y += 42;
        }
        if (Modules.on("Armor Status")) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            int ay = c.getWindow().getScaledHeight() / 2 - 32;
            for (EquipmentSlot s : slots) {
                ItemStack st = c.player.getEquippedStack(s);
                if (!st.isEmpty()) {
                    g.drawItem(st, c.getWindow().getScaledWidth() - 22, ay);
                    g.drawStackOverlay(tr, st, c.getWindow().getScaledWidth() - 22, ay);
                }
                ay += 18;
            }
        }
    }
}
