@echo off
setlocal
set GRADLE_VERSION=8.14.3
set DIST_NAME=gradle-%GRADLE_VERSION%-bin
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set BASE=%GRADLE_USER_HOME%\wrapper\dists\candyclient\%GRADLE_VERSION%
set GRADLE_HOME=%BASE%\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  if not exist "%BASE%\%DIST_NAME%.zip" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/%DIST_NAME%.zip' -OutFile '%BASE%\%DIST_NAME%.zip'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%BASE%\%DIST_NAME%.zip' '%BASE%'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
