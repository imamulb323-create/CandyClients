package com.candyclient;

import net.minecraft.client.MinecraftClient;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Named snapshots of CandyClient's current persistent settings. */
public final class ConfigProfiles {
    private static final String EXT = ".properties";
    private ConfigProfiles() {}

    private static Path root() {
        return MinecraftClient.getInstance().runDirectory.toPath().resolve("config/candyclient/profiles");
    }
    private static Path current() {
        return MinecraftClient.getInstance().runDirectory.toPath().resolve("config/candyclient.properties");
    }
    public static List<String> list() {
        try {
            if (!Files.isDirectory(root())) return List.of();
            try (var files = Files.list(root())) {
                return files.filter(Files::isRegularFile)
                        .filter(p -> p.getFileName().toString().endsWith(EXT))
                        .map(p -> p.getFileName().toString().substring(0, p.getFileName().toString().length() - EXT.length()))
                        .sorted(String.CASE_INSENSITIVE_ORDER).toList();
            }
        } catch (IOException ignored) { return List.of(); }
    }
    private static String safeName(String name) {
        if (name == null) return null;
        String cleaned = name.trim().replaceAll("[^A-Za-z0-9 _-]", "").replaceAll("\\s+", " ");
        if (cleaned.isBlank() || cleaned.length() > 24 || cleaned.equals(".") || cleaned.equals("..")) return null;
        return cleaned;
    }
    private static Path profile(String name) {
        String safe = safeName(name);
        return safe == null ? null : root().resolve(safe + EXT);
    }
    public static boolean save(String name) {
        Path target = profile(name);
        if (target == null) return false;
        try {
            ClientConfig.save();
            if (!Files.isRegularFile(current())) return false;
            Files.createDirectories(root());
            Path temp = target.resolveSibling(target.getFileName() + ".tmp");
            Files.copy(current(), temp, StandardCopyOption.REPLACE_EXISTING);
            try { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException unsupported) { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ignored) { return false; }
    }
    public static boolean load(String name) {
        Path source = profile(name);
        if (source == null || !Files.isRegularFile(source)) return false;
        try {
            Files.createDirectories(current().getParent());
            Path temp = current().resolveSibling(current().getFileName() + ".tmp");
            Files.copy(source, temp, StandardCopyOption.REPLACE_EXISTING);
            try { Files.move(temp, current(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException unsupported) { Files.move(temp, current(), StandardCopyOption.REPLACE_EXISTING); }
            ClientConfig.load();
            return true;
        } catch (IOException ignored) { return false; }
    }
    public static boolean delete(String name) {
        Path target = profile(name);
        if (target == null) return false;
        try { return Files.deleteIfExists(target); }
        catch (IOException ignored) { return false; }
    }
    public static boolean rename(String oldName, String newName) {
        Path source = profile(oldName), target = profile(newName);
        if (source == null || target == null || !Files.isRegularFile(source) || Files.exists(target)) return false;
        try { Files.move(source, target); return true; }
        catch (IOException ignored) { return false; }
    }
    public static boolean exportToGameConfig(String name) {
        Path source = profile(name);
        if (source == null || !Files.isRegularFile(source)) return false;
        try {
            Path exports = MinecraftClient.getInstance().runDirectory.toPath().resolve("config/candyclient/exports");
            Files.createDirectories(exports);
            Files.copy(source, exports.resolve(source.getFileName()), StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (IOException ignored) { return false; }
    }
}
